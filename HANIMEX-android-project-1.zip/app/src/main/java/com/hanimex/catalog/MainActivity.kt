package com.hanimex.catalog

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var cb: ValueCallback<Array<Uri>>? = null
    private val host = "appassets.androidplatform.net"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this); setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = false; mediaPlaybackRequiresUserGesture = false
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) =
                loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == host) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, c: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                cb?.onReceiveValue(null); cb = c
                return try { startActivityForResult(p.createIntent(), 1); true }
                catch (e: Exception) { cb = null; false }
            }
        }
        web.addJavascriptInterface(Bridge(), "AB")
        web.loadUrl("https://$host/assets/index.html")
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 1) { cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); cb = null }
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class Bridge {
        private val sf get() = File(filesDir, "state.json")

        @JavascriptInterface fun setState(s: String) {
            val t = File(filesDir, "state.tmp"); t.writeText(s); t.renameTo(sf)
        }
        @JavascriptInterface fun getState(): String = if (sf.exists()) sf.readText() else ""

        @JavascriptInterface fun save(name: String, mime: String, b64: String) {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime)
            }
            val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
            contentResolver.openOutputStream(u)?.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
        }
        @JavascriptInterface fun share(name: String, mime: String, b64: String) {
            val f = File(File(cacheDir, "s").apply { mkdirs() }, name)
            f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
            val u = FileProvider.getUriForFile(this@MainActivity, "com.hanimex.catalog.fp", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = mime; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            runOnUiThread { startActivity(Intent.createChooser(i, "HANIMEX")) }
        }
        @JavascriptInterface fun text(t: String) {
            val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, t) }
            runOnUiThread { startActivity(Intent.createChooser(i, "HANIMEX")) }
        }
    }
}
